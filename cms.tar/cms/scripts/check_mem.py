#! /usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys

def UsagePercent (use, total):
	try:
		ret = (float(use) / total) * 100
	except ZeroDivisionError:
		print("ERROR - Zero Division Error.")
		sys.exit(3)
	return ret

def GetPhyMem ():
	try:
		f = open('/proc/meminfo', 'r')
		for line in f:
			if line.startswith('MemTotal:'):
				mem_total = int(line.split()[1])
			elif line.startswith('MemFree:'):
				mem_free = int(line.split()[1])
			elif line.startswith('Buffers:'):
				mem_buffer = int(line.split()[1])
			elif line.startswith('Cached:'):
				mem_cache = int(line.split()[1])
			else:
				continue
		f.close()
	except:
		print("ERROR - /proc/meminfo文件访问失败")
		sys.exit(3)
	return (mem_total, mem_free, mem_buffer, mem_cache)
	
def CheckMem ():
	try:
		total, free, buffers, cache = GetPhyMem()
		percent = UsagePercent(total - (free + buffers + cache), total)
	except:
		print("ERROR - 检测系统内存使用率失败")
		sys.exit(3)
	return percent

if __name__=="__main__":
	ct = float(sys.argv[2])
	res = CheckMem()
	if res > ct:
		print("CRITICAL - 系统内存使用率为: %.1f%% | SYS_MEM=%.1f" % (res, res))
		sys.exit(2)
	else:
		print("OK - 系统内存使用率为: %.1f%% | SYS_MEM=%.1f" % (res, res))
		sys.exit(0)

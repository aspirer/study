#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys

def GetProcNum ():
	try:
		num = 0
		pids = [int(x) for x in os.listdir('/proc') if x.isdigit()]
		num = len(pids)
	except:
		print("ERROR - /proc目录访问失败")
		sys.exit(3)
	if not num:
		print("CRITICAL - 系统中无任何进程存在.")
		sys.exit(2)
	return num

if __name__=="__main__":
	ct = float(sys.argv[2])
	res = GetProcNum ()
	if res > ct:
		print("CRITICAL - 系统总进程数为: %s | SYS_PROC=%s" % (res, res))
		sys.exit(2)
	else:
		print("OK - 系统总进程数为: %s | SYS_PROC=%s" % (res, res))
		sys.exit(0)

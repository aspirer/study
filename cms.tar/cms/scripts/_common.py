#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys

TMPDIR="/usr/local/cms/tmp/"
def CheckProcName (pn):
	for i in pn:
		if not i.isalnum():
			if i == '-' or i == '.' or i == '_':
				continue
			else:
				return 0
	return 1

def GetUt ():
	try:
		f = open('/proc/uptime','r')
		ut = float(f.readline().split()[0])
		f.close()
	except:
		print("ERROR - /proc/uptime文件无法访问.")
		sys.exit(3)
	return ut

def CheckTmpFile (fn, now_time, ut, ut_index):
	try:
		f = open(fn, 'r')
	except:
		print("ERROR - 打开数据文件 %s 出错." % (fn,))
		sys.exit(3)
	else:
		try:
			out = float(f.readline().split('#')[ut_index])
		except:
			f.close()
			return -1
		else:
			mode = os.stat(fn)
			f.close()
			if (now_time - int(mode.st_mtime) >= 3600) or (ut <= out):
				return 0
			else:
				return 1
	
def WriteTmpFile (fn, value):
	try:
		f = open(fn, 'w')
		f.write(value)
		f.flush()
		os.fsync(f)
		f.close()
	except:
		print("ERROR - 无法写入数据到 %s 目录." % (TMPDIR,))
		sys.exit(3)

def ReadTmpFile (fn, value):
	values = []
	try:
		f = open(fn, 'r')
	except:
		print("ERROR - 打开数据文件 %s 出错." % (fn,))
		sys.exit(3)
	else:
		try:
			values = f.readline().split('#')
		except:
			f.close()
			return -1
		else:
			f.close()
			WriteTmpFile (fn, value)
	return values

#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import time
import _common

def GetSysCpuTime ():
	try:
		f = open('/proc/stat', 'r')
		values = f.readline().split()
		total_time = 0
		for i in values[1:]:
			total_time += int(i)
		idle_time = int(values[4])
		f.close()
	except:
		print("ERROR - /proc/stat文件无法访问")
		sys.exit(3)
	return (idle_time, total_time)

def BeginCheck (filen, ut):
	(it, tt) = GetSysCpuTime ()
	data = "%s#%s#%s" % (it, tt, ut)
	_common.WriteTmpFile (filen, data)
	
def CheckCpu (id):
	filen = "%s.cms_%s.tmp" % (_common.TMPDIR,id)
	ut = _common.GetUt ()
	if os.path.exists(filen):
		res = _common.CheckTmpFile (filen, int(time.time()), ut, 2)
		if res:
			if res == -1:
				BeginCheck (filen, ut)
				return -4
			(it, tt) = GetSysCpuTime ()
			data = "%s#%s#%s" % (it, tt, ut)

			values = []
			values = _common.ReadTmpFile (filen, data)
			if not values:
				print("ERROR - 无法从 %s 读数据" % (filen,))
				sys.exit(3)
			if values == -1:
				BeginCheck (filen, ut)
				return -4

			oit = int(values[0])
			ott = int(values[1])
			
			ntt = tt - ott
			nit = it - oit
			return  float(100) * (ntt - nit)/ntt
		
		else:
			BeginCheck (filen, ut)
			return -4
	
	else:
		BeginCheck (filen, ut)
		return -4

if __name__=="__main__":
	ct = float(sys.argv[2])
	eid = sys.argv[4]
	res = CheckCpu(eid)
	if res == -4:
		print("OK - 开始检查")
		sys.exit(0)
	else:
		if res > ct:
			print("CRITICAL - 系统CPU使用率为: %.2f%% | SYS_CPU=%.2f" % (res, res))
			sys.exit(2)
		else:
			print("OK - 系统CPU使用率为: %.2f%% | SYS_CPU=%.2f" % (res, res))
			sys.exit(0)

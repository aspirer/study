#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys

def GetLoad ():
	try:
		f = open('/proc/loadavg','r')
		tmp = f.readline().split()
		lavg_1 = float(tmp[0])
		lavg_5 = float(tmp[1])
		lavg_15 = float(tmp[2])
		f.close()
	except:
		print("ERROR - /proc/loadavg文件无法访问")
		sys.exit(3)
	return (lavg_1, lavg_5, lavg_15)

if __name__=="__main__":
	(l1, l5, l15) =  GetLoad ()
	ct5 = float(sys.argv[2])

	if l5 > ct5:
		print("CRITICAL - 系统负载为: %s, %s, %s | LOAD1=%s|LOAD5=%s|LOAD15=%s" % (l1, l5, l15, l1, l5, l15))
		sys.exit(2)
	else:
		print("OK - 系统负载为: %s, %s, %s | LOAD1=%s|LOAD5=%s|LOAD15=%s" % (l1, l5, l15, l1, l5, l15))
		sys.exit(0)

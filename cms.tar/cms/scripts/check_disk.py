#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys

black_list = ('iso9660',)
def UsagePercent (use, total):
	try:
		ret = (float(use) / total) * 100
	except ZeroDivisionError:
		print("ERROR - zero division error in check_disk.py")
		sys.exit(3)
	return ret

def GetDiskPartition ():
	return_list = []
	pd = []
	try:
		f = open("/proc/filesystems", "r")
		for line in f:
			if not line.startswith("nodev"):
				fs_type = line.strip()
				if fs_type not in black_list:
					pd.append(fs_type)
		f.close()
		pd.append('nfs')
		pd.append('nfs4')

		f = open('/etc/mtab', "r")
		for line in f:
			if line.startswith('none'):
				continue
			tmp = line.strip().split()
			ft = tmp[2]
			if ft not in pd:
				continue
			return_list.append(tmp[1])
		f.close()
	except:
		print("ERROR - 从 /proc/filesystems 或 /etc/mtab 获取分区表失败")
		sys.exit(3)
	if not return_list:
		print("ERROR - 从 /proc/filesystems 或 /etc/mtab 获取分区表失败")
		sys.exit(3)
	return return_list

def CheckDisk ():
	try:
		return_dict = {}
		p_list = GetDiskPartition()
		for i in p_list:
			dt = os.statvfs(i)
			use = (dt.f_blocks - dt.f_bfree) * dt.f_frsize
			all = dt.f_blocks * dt.f_frsize
			return_dict[i] = ('%.0f' % (UsagePercent(use, all),), ('%.2f' % (all*1.0/(1024*1000000))))
	except:
		print("ERROR - 检测磁盘使用率失败")
		sys.exit(3)
	if not return_dict:
		print("ERROR - 检测磁盘使用率失败")
		sys.exit(3)
	return return_dict

if __name__=="__main__":
	ct = float(sys.argv[2])
	tmpd = CheckDisk()
	tmpr = []
	for kk in tmpd:
		if int(tmpd[kk][0]) > ct:
			tmpr.append(kk)
	res = ""
	perf = ""
	for p in tmpd:
		if perf:
			perf = "%s|%s=%s,%s" % (perf, p, tmpd[p][0], tmpd[p][1])
		else:
			perf = "%s=%s,%s" % (p, tmpd[p][0], tmpd[p][1])
	if not tmpr:
		for kk in tmpd:
			if res:
				res = "%s %s 使用 %s%%" % (res, kk, tmpd[kk][0])
			else:
				res = "%s 使用 %s%%" % (kk, tmpd[kk][0])
		print("OK - %s|%s" % (res, perf))
		sys.exit(0)
	else:
		for kk in tmpr:
			if res:
				res = "%s %s 使用 %s%%" % (res, kk, tmpd[kk][0])
			else:
				res = "%s 使用 %s%%" % (kk, tmpd[kk][0])
		print("CRITICAL - %s|%s" % (res, perf))
		sys.exit(2)

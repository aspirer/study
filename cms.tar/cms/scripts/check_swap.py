#! /usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys

def UsagePercent (use, total):
	try:
		ret = (float(use) / total) * 100
	except ZeroDivisionError:
		print("ERROR - 系统未设置SWAP.")
		sys.exit(3)
	return ret

def CheckSwap ():
	try:
		f = open('/proc/meminfo', 'r')
		total = free = None
		for line in f:
			if line.startswith('SwapTotal:'):
				total = int(line.split()[1]) * 1024
			elif line.startswith('SwapFree:'):
				free = int(line.split()[1]) * 1024
			if total is not None and free is not None:
				break
		f.close()
		assert total is not None and free is not None
		used = total - free
		percent = UsagePercent(used, total)
		return percent
	except:
		print("ERROR - 检测系统SWAP使用率失败")
		sys.exit(3)

if __name__=="__main__":
	ct = float(sys.argv[2])
	res = CheckSwap()
	if res > ct:
		print("CRITICAL - 系统swap利用率为: %.1f%% | SYS_SWAP=%.1f" % (res, res))
		sys.exit(2)
	else:
		print("OK - 系统swap利用率为: %.1f%% | SYS_SWAP=%.1f" % (res, res))
		sys.exit(0)

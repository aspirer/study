#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import subprocess
import _common

def UsagePercent (use, total):
        try:
                ret = (float(use) / total) * 100
        except ZeroDivisionError:
                print("ERROR - zero division Error.")
                sys.exit(3)
        return ret

def GetMemTotal ():
        try:
                f = open('/proc/meminfo', 'r')
                for line in f:
                        if line.startswith('MemTotal:'):
                                mem_total = int(line.split()[1])
                                break
                        else:
                                continue
                f.close()
        except:
                print("ERROR - /proc/meminfo文件访问失败")
                sys.exit(3)
        return mem_total

def GetPageSize ():
        try:
                res = subprocess.Popen(args='getconf PAGESIZE', shell=True, stdout=subprocess.PIPE)
                ps = int(res.stdout.read().strip())
        except:
                print("ERROR - 无法获取内存PAGE大小")
                sys.exit(3)
        return ps/1024

def GetProcRss (pn, ps):
	sr = 0
	fg = 0
	for x in os.listdir('/proc'):
		if not x.isdigit():
			continue
		else:
			try:
				f = open("/proc/%s/stat" % (x,),'r')
			except:
				pass
			else:
				try:
                                	tmp = f.read().split()
				except:
					f.close()
				else:
					f.close()
					if (tmp[1].replace('(', '').replace(')', '').strip() == pn.strip()):
						fg = 1
						try:
							ff = open("/proc/%s/statm" % (x,),'r')
						except:
							pass
						else:
							try:
								tmp = ff.read().split()
							except:
								ff.close()
							else:
								ff.close()
								sr = sr + int(tmp[1])
					else:
						continue
	if not fg:
		return 0
	else:
		return sr*ps

if __name__=="__main__":
        pn = sys.argv[1].split()[0].split('/')[-1]
        if not _common.CheckProcName(pn):
                print("ERROR - 进程名格式非法")
                sys.exit(3)
        ct = float(sys.argv[2])
        pu = GetProcRss (pn, GetPageSize ())
        if pu > 0:
                res = UsagePercent(pu, GetMemTotal ())
                if res > ct:
                        print("CRITICAL - 进程 %s 的内存使用率为: %.2f%% | PROC_MEM=%.2f" % (pn, res, res))
                        sys.exit(2)
                else:
                        print("OK - 进程 %s 的内存使用率为: %.2f%% | PROC_MEM=%.2f" % (pn, res, res))
                        sys.exit(0)
        else:
                print("CRITICAL - 系统中未找到进程: %s" % (pn,))
                sys.exit(2)

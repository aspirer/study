#! /bin/bash

POLICY_PARAMS=`echo "$1" |sed 's/-/\\\-/g' |sed 's/!/\\\!/g' |sed 's/\[/\\\[/g' |sed 's/\]/\\\]/g' |sed 's/</\\\</g' |sed 's/>/\\\>/g' |sed 's/\./\\\./g' |sed 's/\^/\\\^/g' |sed 's/\*/\\\*/g' |sed 's/\"/\\\"/g' |sed 's#\\$#\\\\$#g'`
if [ -z "$POLICY_PARAMS" ]
then
   echo "CRITICAL - 请输入进程名."
   exit 2
fi
CURRENT_PROC=`ps -ef |grep -wv grep |grep -v 'check_proc_alive.py' |grep "$POLICY_PARAMS" |wc -l`
if [ "$CURRENT_PROC" -gt 0 ]
then
   echo "OK - 进程 "$1" 存在."
   exit 0
else
   echo "CRITICAL - 进程 "$1" 不存在."
   exit 2
fi

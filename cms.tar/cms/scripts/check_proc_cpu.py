#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import time
import _common

def GetCpuNum ():
	try:
		return os.sysconf("SC_NPROCESSORS_ONLN")
	except ValueError:
		num = 0
		f = open('/proc/cpuinfo', 'r')
		try:
			lines = f.readlines()
		finally:
			f.close()
		for line in lines:
			if line.lower().startswith('processor'):
				num += 1
	if num == 0:
		f = open('/proc/stat', 'r')
		try:
			lines = f.readlines()
		finally:
			f.close()
		search = re.compile('cpu\d')
		for line in lines:
			line = line.split(' ')[0]
			if search.match(line):
				num += 1
	if num == 0:
		print("ERROR - 获取系统CPU数目失败")
		sys.exit(3)
	return num

def GetSysTime ():
	try:
		total_time = 0
		f = open('/proc/stat', 'r')
		values = f.readline().split()
		f.close()
		for i in values[1:]:
			total_time += int(i)
	except:
		print("ERROR - /proc/stat文件无法访问")
		sys.exit(3)
	return total_time

def GetProcTime (pn, cn):
	sr = 0
	fg = 0
	for x in os.listdir('/proc'):
		if not x.isdigit():
			continue
		else:
			try:
				f = open("/proc/%s/stat" % (x,),'r')
			except:
				pass
			else:
				try:
					tmp = f.read().split()
				except:
					f.close()
				else:
					f.close()
					if (tmp[1].replace('(', '').replace(')', '').strip() == pn.strip()):
						fg = 1
						sr = sr + int(tmp[13]) + int(tmp[14]) + int(tmp[15]) + int(tmp[16])
					else:
						continue
	if not fg:
		return 4
	else:
		return sr*cn	

def CheckProcCpu (pn, id):
        filen = "%s.cms_%s.tmp" % (_common.TMPDIR, id)
        ut = _common.GetUt ()
        cn = GetCpuNum ()

        if os.path.exists(filen):
		res = _common.CheckTmpFile (filen, int(time.time()), ut, 2)
                if res:
			if res == -1:
				tt = GetSysTime ()
				pt = GetProcTime (pn, cn)
				if pt == 4:
					return 4
				data = "%s#%s#%s" % (pt, tt, ut)
				_common.WriteTmpFile (filen, data)
				return -4
                        tt = GetSysTime ()
                        pt = GetProcTime (pn, cn)
                        if pt == 4:
                                return 4
                        data = "%s#%s#%s" % (pt, tt, ut)
                        values = []
                        values = _common.ReadTmpFile (filen, data)
                        if not values:
                                print("ERROR - 无法从 %s 读取数据" % (filen,))
                                sys.exit(3)
			if values == -1:
				tt = GetSysTime ()
                                pt = GetProcTime (pn, cn)
                                if pt == 4:
                                        return 4
                                data = "%s#%s#%s" % (pt, tt, ut)
                                _common.WriteTmpFile (filen, data)
                                return -4
                        opt = int(values[0])
                        ott = int(values[1])
                        npt = pt - opt
                        ntt = tt - ott
                        return float(100)*npt/ntt
                else:
                        tt = GetSysTime ()
                        pt = GetProcTime (pn, cn)
                        if pt == 4:
                                return 4
                        data = "%s#%s#%s" % (pt, tt, ut)
                        _common.WriteTmpFile (filen, data)
                        return -4
        else:
                tt = GetSysTime ()
                pt = GetProcTime (pn, cn)
                if pt == 4:
                        return 4
                data = "%s#%s#%s" % (pt, tt, ut)
                _common.WriteTmpFile (filen, data)
                return -4

if __name__=="__main__":
        pn = sys.argv[1].split()[0].split('/')[-1]
        eid = sys.argv[4]
        if not _common.CheckProcName(pn):
                print("ERROR - 进程名格式错误")
                sys.exit(3)

        ct = float(sys.argv[2])
        res = CheckProcCpu (pn, eid)
        if res == 4:
                print("CRITICAL - 系统中未找到进程: %s" % (pn,))
                sys.exit(2)
        elif res == -4:
                print("OK - 开始检查")
                sys.exit(0)
        else:
                if res > ct:
                        print("CRITICAL - 进程 %s 的CPU使用率为: %.2f%% | PROC_CPU=%.2f" % (pn, res, res))
                        sys.exit(2)
                else:
                        print("OK - 进程 %s 的CPU使用率为: %.2f%% | PROC_CPU=%.2f" % (pn, res, res))
                        sys.exit(0)

#! /bin/bash
export PATH=$PATH:/usr/sbin:/sbin:/bin:/usr/bin

POLICY_PARAMS=$1
CRITICAL_PARAMS=$2
TIMEOUT=$3

ce=`netstat -an |grep -v grep |grep tcp |grep ESTABLISHED|wc -l`
if [ -z "$ce" ];then
    echo "ERROR - 获取系统已建立TCP连接总数失败"
    exit 3;
fi
expr "$ce" + 4 > /dev/null 2>&1
if [ $? -ne 0 ];then
    echo "ERROR - 获取系统已建立TCP连接总数失败"
    exit 3
fi
if [ "$ce" -ge "$CRITICAL_PARAMS" ];then
    echo "CRITICAL - 系统已建立TCP连接总数为: "$ce" | SYS_TCP="$ce""
    exit 2
else
    echo "OK - 系统已建立TCP连接总数为: "$ce" | SYS_TCP="$ce""
    exit 0
fi

#! /usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import time
import _common
import platform

def GetNetData (ifp):
	try:
		bytes_recv = 0
		bytes_sent = 0
		if_file_path = "/proc/net/dev"
		if platform.architecture()[0] == '32bit':
			if_file_path = _common.TMPDIR + ".interface"
		f = open(if_file_path, "r")
		all_lines = f.readlines()
		if not all_lines:
			time.sleep(0.2)
			all_lines = f.readlines()
		f.close()
		for line in all_lines[2:]:
			fields = line.split(':')
			name = fields[0].strip()
			if name == ifp.strip():
				tmp = fields[1].split()
				bytes_recv = int(tmp[0])
				bytes_sent = int(tmp[8])
				break
			else:
				continue
	except:
		print("ERROR - %s文件无法访问" % if_file_path)
		sys.exit(3)
	if (not bytes_recv) or (not bytes_sent):
		print("ERROR - 未找到网卡: %s" % (ifp,))
		sys.exit(3)
	return (bytes_recv, bytes_sent)

def BeginCheck (ifp, filen, ut, nt):
	(br, bs) = GetNetData (ifp)
	data = "%s#%s#%s#%s" % (br, bs, nt, ut)
	_common.WriteTmpFile (filen, data)

def CheckNet (ifp, id):
	filen = "%s.cms_%s.tmp" % (_common.TMPDIR,id)
	ut = _common.GetUt ()
	nt = int(time.time())
	if os.path.exists(filen):
		res = _common.CheckTmpFile (filen, nt, ut, 3)
		if res:
			if res == -1:
				BeginCheck (ifp, filen, ut, nt)
				return (-4, -4)
			(br, bs) = GetNetData (ifp)
			data = "%s#%s#%s#%s" % (br, bs, nt, ut)

			values = []
			values = _common.ReadTmpFile (filen, data)
			if not values:
				print("ERROR - 无法从 %s 读取数据" % (filen,))
				sys.exit(3)
			if values == -1:
				BeginCheck (ifp, filen, ut, nt)
				return (-4, -4)
			obr = int(values[0])
			obs = int(values[1])
			ot = int(values[2])

			if ((br-obr) < 0) or ((bs-obs) < 0):
				BeginCheck (ifp, filen, ut, nt)
				return (-4, -4)

			return ((br-obr)/(nt-ot)/float(1024)*8, (bs-obs)/(nt-ot)/float(1024)*8)
		else:
			BeginCheck (ifp, filen, ut, nt)
			return (-4, -4)

	else:
		BeginCheck (ifp, filen, ut, nt)
		return (-4, -4)

if __name__=="__main__":
	try:
		ifp = sys.argv[1].split()[0]
	except:
		print("CRITICAL - 未填入网卡名称，请填入网卡名称，例如: eth0 等")
		sys.exit(2)
	eid = sys.argv[4]
	ct = float(sys.argv[2])
	br, bs = CheckNet (ifp, eid)
	if br == -4:
		print("OK - 开始检查")
		sys.exit(0)
	if (br > ct) or (bs > ct):
		print("CRITICAL - 网络流量，进: %.2fKb/s, 出: %.2fKb/s | TRAFFIC_IN=%.2f|TRAFFIC_OUT=%.2f" % (br, bs, br, bs))
		sys.exit(2)
	else:
		print("OK - 网络流量, 进: %.2fKb/s, 出: %.2fKb/s| TRAFFIC_IN=%.2f|TRAFFIC_OUT=%.2f" % (br, bs, br, bs))
		sys.exit(0)
